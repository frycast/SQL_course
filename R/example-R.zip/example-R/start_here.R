source("functions.R")
library(RSQLite)
library(dbplyr)

# Basic SQLite ------------------------------------------------------------

# create the db
con <- DBI::dbConnect(RSQLite::SQLite(), "data/test_database.sqlite")

# disconnect
DBI::dbDisconnect(con)

# reconnect
con <- DBI::dbConnect(RSQLite::SQLite(), "data/test_database.sqlite")

# read csv into R
example_data <- read.csv("data/example_data.csv")

# TODO: processing/cleaning needed before inserting data?

# insert data into database
DBI::dbWriteTable(con, "example", example_data)
DBI::dbListTables(con)

# retrieve the data using SQL code
query1 <- "
  SELECT *
  FROM example;
"
result <- DBI::dbGetQuery(con,query1)

# retrieve the data using functions
result <- DBI::dbReadTable(con, "example")

# disconnect
DBI::dbDisconnect(con)

# Tidyverse tools ---------------------------------------------------------

con <- DBI::dbConnect(RSQLite::SQLite(), "data/Sandpit.sqlite")

# connect to banana table
banana <- dplyr::tbl(con, "Ape_Banana")
banana

# connect to banana table but filter for ripe bananas
ripe_banana <- banana %>% 
  dplyr::filter(Ripe == 1)
ripe_banana

# the object has a SQL query hidden in it
ripe_banana %>% dplyr::show_query()

# execute the query and get the full result
result <- ripe_banana %>% dplyr::collect()

# when you write your own query, it returns a whole data.frame (not connection object)
query1 <- "
SELECT TreeID, COUNT(*) AS NumRipe, AVG(TasteRank) AS AvgTaste 
FROM Ape_Banana
WHERE DatePicked > '20180101'
GROUP BY TreeID;
"
result <- DBI::dbGetQuery(con, query1)

# same query in dplyr syntax
tasty_bananas <- banana %>% 
  dplyr::filter(DatePicked > '20180101') %>% 
  dplyr::group_by(TreeID) %>% 
  dplyr::summarise(NumRipe = n(), AvgTaste = mean(TasteRank, na.rm=T))

# show the query
tasty_bananas %>% dplyr::show_query()

# retrieve whole table
result <- tasty_bananas %>% dplyr::collect()
result













