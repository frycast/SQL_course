# A function that checks if x is 'blue'
is_x_blue <- function(x) {
  x == 'blue'
}